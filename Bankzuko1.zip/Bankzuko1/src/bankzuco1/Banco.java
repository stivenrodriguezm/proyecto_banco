
package bankzuco1;

import java.awt.Image;
import java.awt.Toolkit;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;



public class Banco extends javax.swing.JFrame {
    ArrayList<Cliente> listaClientes=new ArrayList<Cliente>();
    ArrayList<String> listaTipoCuenta=new ArrayList<String>();
    DefaultTableModel modelMovs=new DefaultTableModel();
    Cliente cliente;
    Cuenta cuenta;
    public Banco() {
        initComponents();
        this.setTitle("Bankzuco");
        Image img=Toolkit.getDefaultToolkit().getImage(getClass().getResource("/img/logo.png"));
        lblLogo.setIcon(new ImageIcon(img.getScaledInstance(lblLogo.getWidth(), lblLogo.getHeight(), Image.SCALE_SMOOTH)));
        this.setLocationRelativeTo(null);
        modelMovs.addColumn("CUENTA");
        modelMovs.addColumn("FECHA");
        modelMovs.addColumn("TIPO");
        modelMovs.addColumn("MONTO");
        tblMovimientos.setModel(modelMovs);
         
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblLogo = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        txtNombreCliente = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtDireccionCliente = new javax.swing.JTextField();
        btnAgregarUsuario = new javax.swing.JButton();
        txtTelefonoCliente = new javax.swing.JPasswordField();
        jPanel2 = new javax.swing.JPanel();
        btnAgregrarTipoCuenta = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btnAgregarCuenta = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        cboCuentaCliente = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        cboTipoCuenta = new javax.swing.JComboBox<>();
        txtMontoInicial = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        cboConsultaCliente = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        cboConsultaTipoCuenta = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        cboTipoMovimiento = new javax.swing.JComboBox<>();
        txtMontoMovimiento = new javax.swing.JTextField();
        btnAgregarMovimiento = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        lblMontoInicial = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        lblTipoCuentaCliente = new javax.swing.JLabel();
        lblNombreCliente = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        lblDireccionCliente = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblMovimientos = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        lblSaldo = new javax.swing.JLabel();
        lblTelefonoCliente = new javax.swing.JLabel();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 10), new java.awt.Dimension(0, 10), new java.awt.Dimension(32767, 10));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Logo.png"))); // NOI18N
        getContentPane().add(lblLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 280, 290));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setText("Bankzuco");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, -1, -1));

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Crear Usuario"));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setText("Contraseña:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, -1, -1));

        txtNombreCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreClienteActionPerformed(evt);
            }
        });
        jPanel1.add(txtNombreCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 40, 130, -1));

        jLabel5.setText("Nombre:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 38, -1, -1));

        jLabel7.setText("Direccion:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, -1, -1));

        txtDireccionCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDireccionClienteActionPerformed(evt);
            }
        });
        jPanel1.add(txtDireccionCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 140, 130, -1));

        btnAgregarUsuario.setText("Agregar Usuario");
        btnAgregarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarUsuarioActionPerformed(evt);
            }
        });
        jPanel1.add(btnAgregarUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 200, 130, 30));
        jPanel1.add(txtTelefonoCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 90, 130, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 50, 240, 250));

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Crear cuenta"));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnAgregrarTipoCuenta.setText("+");
        btnAgregrarTipoCuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregrarTipoCuentaActionPerformed(evt);
            }
        });
        jPanel2.add(btnAgregrarTipoCuenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 100, 50, -1));

        jLabel1.setText("Monto inicial:");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, -1, -1));

        btnAgregarCuenta.setText("Agregar Cuenta");
        btnAgregarCuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarCuentaActionPerformed(evt);
            }
        });
        jPanel2.add(btnAgregarCuenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 200, 140, 30));

        jLabel8.setText("Cliente:");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, -1, -1));

        jPanel2.add(cboCuentaCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 40, 140, -1));

        jLabel11.setText("Tipo de Cuenta:");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 90, -1));

        jPanel2.add(cboTipoCuenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 100, 80, -1));

        txtMontoInicial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMontoInicialActionPerformed(evt);
            }
        });
        jPanel2.add(txtMontoInicial, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 160, 140, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 50, 280, 250));
        jPanel2.getAccessibleContext().setAccessibleName("Crear cuenta");

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Movimientos"));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setText("Cliente:");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 90, -1));

        cboConsultaCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboConsultaClienteActionPerformed(evt);
            }
        });
        jPanel3.add(cboConsultaCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 140, 30));

        jLabel3.setText("Tipo de Cuenta:");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 30, 90, -1));

        cboConsultaTipoCuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboConsultaTipoCuentaActionPerformed(evt);
            }
        });
        jPanel3.add(cboConsultaTipoCuenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 50, 140, 30));

        jLabel9.setText("Tipo de Movimiento:");
        jPanel3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 30, 120, -1));

        jLabel10.setText("Monto:");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 30, 90, -1));

        cboTipoMovimiento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Consignar", "Retirar" }));
        cboTipoMovimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboTipoMovimientoActionPerformed(evt);
            }
        });
        jPanel3.add(cboTipoMovimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 50, 150, 30));

        txtMontoMovimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMontoMovimientoActionPerformed(evt);
            }
        });
        jPanel3.add(txtMontoMovimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 50, 140, 30));

        btnAgregarMovimiento.setText("Agregar Movimiento");
        btnAgregarMovimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarMovimientoActionPerformed(evt);
            }
        });
        jPanel3.add(btnAgregarMovimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 50, 150, 30));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 360, 840, 110));

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Datos del Usuario"));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblMontoInicial.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        jPanel4.add(lblMontoInicial, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, 130, 30));

        jLabel13.setText("Direccion:");
        jPanel4.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, -1, -1));

        lblTipoCuentaCliente.setBackground(new java.awt.Color(153, 51, 255));
        jPanel4.add(lblTipoCuentaCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, 130, 30));
        jPanel4.add(lblNombreCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 20, 140, 30));

        jLabel15.setText("Nombre:");
        jPanel4.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, -1, -1));

        jLabel16.setText("Tipo de Cuenta:");
        jPanel4.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, -1));

        jLabel17.setText("Monto Incial:");
        jPanel4.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, -1, -1));
        jPanel4.add(lblDireccionCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 60, 130, 30));

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 480, 270, 200));

        tblMovimientos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tblMovimientos);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 490, 550, 140));

        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 550, -1, -1));

        lblSaldo.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblSaldo.setText("Saldo");
        getContentPane().add(lblSaldo, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 640, 550, -1));

        lblTelefonoCliente.setFont(new java.awt.Font("Segoe UI", 0, 1)); // NOI18N
        getContentPane().add(lblTelefonoCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 630, 90, 30));
        getContentPane().add(filler1, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 690, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNombreClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreClienteActionPerformed

    private void txtMontoMovimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMontoMovimientoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMontoMovimientoActionPerformed

    private void btnAgregarCuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarCuentaActionPerformed
        cliente=listaClientes.get(cboCuentaCliente.getSelectedIndex());
        Cuenta cuenta= new Cuenta ();
        cuenta.setTipocuenta(listaTipoCuenta.get(cboTipoCuenta.getSelectedIndex()));
        cuenta.setMontoinicial(Double.parseDouble(txtMontoInicial.getText()));
        cliente.addCuenta(cuenta);
        Movimiento m=new Movimiento();
        m.setFechaMovimiento(new SimpleDateFormat("dd/MM/yyyy").format(new Date()));
        m.setTipoMovimiento("APERTURA");
        m.setMonto(Double.parseDouble(txtMontoInicial.getText()));
        cuenta.addMovimiento(m);
        borrarFormCuenta();
        refrescarCombosCuentas();
        verMovimientos();
        
    }//GEN-LAST:event_btnAgregarCuentaActionPerformed

    private void btnAgregrarTipoCuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregrarTipoCuentaActionPerformed
        String tipoCuenta=JOptionPane.showInputDialog(this,"TIPO CUENTA");
        listaTipoCuenta.add(tipoCuenta);
        
        llenarCombosTipoCuenta();
        
        
    }//GEN-LAST:event_btnAgregrarTipoCuentaActionPerformed
public void refrescarCombosCuentas() {
     cliente=listaClientes.get(cboConsultaCliente.getSelectedIndex());
     int i=0;
     ArrayList<String> cuentas=new ArrayList<String>();
     for (Cuenta c : cliente.getMiscuentas()){
         cuentas.add(c.getTipocuenta());
         
     }
       cboConsultaTipoCuenta.setModel(new DefaultComboBoxModel(cuentas.toArray()));  
}
    public void llenarCombosTipoCuenta (){
    Object tipos[]=new Object[listaTipoCuenta.size()];
    int i=0;
    for (String tipo :listaTipoCuenta){
        tipos[i]=tipo;
        i++;
    }
    cboTipoCuenta.setModel(new DefaultComboBoxModel(tipos));
    
    
}
    private void txtDireccionClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDireccionClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDireccionClienteActionPerformed

    private void btnAgregarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarUsuarioActionPerformed
        Cliente c=new Cliente ();
        c.setNombre(txtNombreCliente.getText());
        c.setTelefono(txtTelefonoCliente.getText());
        c.setDireccion (txtDireccionCliente.getText());
        listaClientes.add(c);
        borrarFormCliente();
        llenarCombosCliente();
        
        
    }//GEN-LAST:event_btnAgregarUsuarioActionPerformed
public void llenarCombosCliente (){
    Object clientes[]=new Object[listaClientes.size()];
    int i=0;
    for (Cliente c :listaClientes){
        clientes[i]=c.getNombre();
        i++;
    }
    cboCuentaCliente.setModel(new DefaultComboBoxModel(clientes));
    cboConsultaCliente.setModel(new DefaultComboBoxModel(clientes));
}
    public void borrarFormCuenta(){
        cboCuentaCliente.setSelectedIndex(0);
        cboTipoCuenta.setSelectedIndex(0);
        txtMontoInicial.setText("");
    }
public void borrarFormCliente(){
    txtNombreCliente.setText("");
    txtTelefonoCliente.setText("");
    txtDireccionCliente.setText("");
    
}
    private void txtMontoInicialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMontoInicialActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMontoInicialActionPerformed

    private void btnAgregarMovimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarMovimientoActionPerformed
        cliente = listaClientes.get(cboConsultaCliente.getSelectedIndex());
        cuenta = cliente.getMiscuentas().get(cboConsultaTipoCuenta.getSelectedIndex());

        Movimiento m = new Movimiento();
        m.setFechaMovimiento(new SimpleDateFormat("dd/MM/yyyy").format(new Date()));
        m.setTipoMovimiento(cboTipoMovimiento.getSelectedItem().toString());

        double monto = Double.parseDouble(txtMontoMovimiento.getText());
        monto = m.getTipoMovimiento().equals("DEPOSITO") ? monto : (monto * -1);

        // Verificar si el saldo después del movimiento es menor que cero
        double saldoActual = cuenta.getMontoinicial();
        double nuevoSaldo = saldoActual+monto;
        if (nuevoSaldo < 0) {
            JOptionPane.showMessageDialog(this, "No hay suficiente saldo para realizar el movimiento.", "Error", JOptionPane.ERROR_MESSAGE);
            return;  // Salir del método sin agregar el movimiento
        }else{
            m.setMonto(monto);
            cuenta.addMovimiento(m);
            cuenta.setMontoinicial(nuevoSaldo);
            verMovimientos();
        }
    }//GEN-LAST:event_btnAgregarMovimientoActionPerformed

    private void cboTipoMovimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboTipoMovimientoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboTipoMovimientoActionPerformed

    private void cboConsultaClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboConsultaClienteActionPerformed
        
        refrescarCombosCuentas();
        verMovimientos();
        verDatos();
    }//GEN-LAST:event_cboConsultaClienteActionPerformed

    private void cboConsultaTipoCuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboConsultaTipoCuentaActionPerformed
        verDatos();
        verMovimientos();       
    }//GEN-LAST:event_cboConsultaTipoCuentaActionPerformed
    public String aMoneda(double cantidad){
        cantidad=Math.round(cantidad*100.0)/100.0;
        DecimalFormat formato=new DecimalFormat("$ #,###.## COP ");
        return formato.format(cantidad);
    }
    public void verDatos() {
      cliente = listaClientes.get(cboConsultaCliente.getSelectedIndex());
      lblNombreCliente.setText(cliente.getNombre());
      lblTelefonoCliente.setText(cliente.getTelefono());
      lblDireccionCliente.setText(cliente.getDireccion());
      
      if (cliente.getMiscuentas().size()>0){
          cuenta=cliente.getMiscuentas().get(cboConsultaTipoCuenta.getSelectedIndex());
          
          lblTipoCuentaCliente.setText(cuenta.getTipocuenta());
          lblMontoInicial.setText(aMoneda(cuenta.getMontoinicial()));
      }else {
          jLabel3.setText("NO HAY CUENTA");
          lblMontoInicial.setText("NO HAY CUENTA");
          
      }
    }
    
   public void verMovimientos (){
      cliente= listaClientes.get(cboConsultaCliente.getSelectedIndex());
      cuenta= cliente.getMiscuentas().get(cboConsultaTipoCuenta.getSelectedIndex());
      double saldo=0;
      while(modelMovs.getRowCount()>0){
          modelMovs.removeRow(0);
      }
      for (Movimiento m: cuenta.getMismovimientos()){
          Object mov[]=new Object[4];
          mov[0]= cuenta.getTipocuenta();
          mov[1]= m.getFechaMovimiento();
          mov [2]= m.getTipoMovimiento();
          mov [3]= aMoneda(m.getMonto());
          saldo+=m.getMonto();
          modelMovs.addRow(mov);
      }
      tblMovimientos.setModel(modelMovs);
      lblSaldo.setText(aMoneda(saldo));
   }
    public static void main(String args[]) {
    java.awt.EventQueue.invokeLater(() -> new Banco().setVisible(true));
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregarCuenta;
    private javax.swing.JButton btnAgregarMovimiento;
    private javax.swing.JButton btnAgregarUsuario;
    private javax.swing.JButton btnAgregrarTipoCuenta;
    private javax.swing.JComboBox<String> cboConsultaCliente;
    private javax.swing.JComboBox<String> cboConsultaTipoCuenta;
    private javax.swing.JComboBox<String> cboCuentaCliente;
    private javax.swing.JComboBox<String> cboTipoCuenta;
    private javax.swing.JComboBox<String> cboTipoMovimiento;
    private javax.swing.Box.Filler filler1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblDireccionCliente;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JLabel lblMontoInicial;
    private javax.swing.JLabel lblNombreCliente;
    private javax.swing.JLabel lblSaldo;
    private javax.swing.JLabel lblTelefonoCliente;
    private javax.swing.JLabel lblTipoCuentaCliente;
    private javax.swing.JTable tblMovimientos;
    private javax.swing.JTextField txtDireccionCliente;
    private javax.swing.JTextField txtMontoInicial;
    private javax.swing.JTextField txtMontoMovimiento;
    private javax.swing.JTextField txtNombreCliente;
    private javax.swing.JPasswordField txtTelefonoCliente;
    // End of variables declaration//GEN-END:variables
}
